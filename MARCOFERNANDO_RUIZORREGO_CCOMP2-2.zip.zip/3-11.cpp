#include <iostream>
#include "3-11.h"


int main(){
MotorVehicule testMotorVehicule("nissan","uno",2020,"azul",5000);

testMotorVehicule.displayCarDetails();
return 0;
}